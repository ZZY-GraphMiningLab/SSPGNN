import numpy as np
import torch
import pickle
from model import DBCSSL
from utils import metrics, scipy_sparse_mat_to_torch_sparse_tensor
import pandas as pd
from parser1 import args
from tqdm import tqdm
import time
import torch.utils.data as data
from utils import TrnData
from data_set import DataSet

device = 'cuda:' + args.cuda

# hyperparameters
d = args.d
# d1 = args.d1
l1 = args.gnn_layer1
l2 = args.gnn_layer2
l3 = args.gnn_layer3

cl1 = args.gnn_cl_layer1
cl2 = args.gnn_cl_layer2
cl3 = args.gnn_cl_layer3
temp = args.temp
# temp1 = args.temp1
batch_user = args.batch
epoch_no = args.epoch
max_samp = 40
lambda_1 = args.lambda1
lambda_2 = args.lambda2
lambda_3 = args.lambda3
dropout = args.dropout
lr = args.lr
decay = args.decay
svd_q = args.q
eps = args.eps
path = 'data/' + args.data + '/'
f = open(path + 'view.pkl', 'rb')
train = pickle.load(f)
train_csr = (train != 0).astype(np.float32)
f = open(path + 'cart.pkl', 'rb')
train1 = pickle.load(f)
train_csr1 = (train1 != 0).astype(np.float32)
f = open(path + 'buy.pkl', 'rb')
train2 = pickle.load(f)
train_csr2 = (train2 != 0).astype(np.float32)
f = open(path + 'train.pkl', 'rb')
train3 = pickle.load(f)
train_csr3 = (train3 != 0).astype(np.float32)
f = open(path + 'test.pkl', 'rb')
test2 = pickle.load(f)
print('Data loaded.')

# print('user_num:',train.shape[0],'item_num:',train.shape[1],'lambda_1:',lambda_1,'lambda_2:',lambda_2,'temp:',temp,'q:',svd_q)

epoch_user = min(train2.shape[0], 30000)

# normalizing the adj matrix
rowD = np.array(train.sum(1)).squeeze()
colD = np.array(train.sum(0)).squeeze()
for i in range(len(train.data)):
    train.data[i] = train.data[i] / pow(rowD[train.row[i]] * colD[train.col[i]], 0.5)
rowD1 = np.array(train1.sum(1)).squeeze()
colD1 = np.array(train1.sum(0)).squeeze()
for i in range(len(train1.data)):
    train1.data[i] = train1.data[i] / pow(rowD1[train1.row[i]] * colD1[train1.col[i]], 0.5)
rowD2 = np.array(train2.sum(1)).squeeze()
colD2 = np.array(train2.sum(0)).squeeze()
for i in range(len(train2.data)):
    train2.data[i] = train2.data[i] / pow(rowD2[train2.row[i]] * colD2[train2.col[i]], 0.5)
rowD3 = np.array(train3.sum(1)).squeeze()
colD3 = np.array(train3.sum(0)).squeeze()
for i in range(len(train3.data)):
    train3.data[i] = train3.data[i] / pow(rowD3[train3.row[i]] * colD3[train3.col[i]], 0.5)
# construct data loader
train = train.tocoo()
train_data = TrnData(train)
train_loader = data.DataLoader(train_data, batch_size=args.inter_batch, shuffle=True, num_workers=0)
adj_norm = scipy_sparse_mat_to_torch_sparse_tensor(train)
adj_norm = adj_norm.coalesce().cuda(torch.device(device))
train1 = train1.tocoo()
train_data1 = TrnData(train1)
train_loader1 = data.DataLoader(train_data1, batch_size=args.inter_batch, shuffle=True, num_workers=0)
adj_norm1 = scipy_sparse_mat_to_torch_sparse_tensor(train1)
adj_norm1 = adj_norm1.coalesce().cuda(torch.device(device))
train2 = train2.tocoo()
train_data2 = TrnData(train2)
train_loader2 = data.DataLoader(train_data2, batch_size=args.inter_batch, shuffle=True, num_workers=0)
adj_norm2 = scipy_sparse_mat_to_torch_sparse_tensor(train2)
adj_norm2 = adj_norm2.coalesce().cuda(torch.device(device))
train3 = train3.tocoo()
train_data3 = TrnData(train3)
train_loader3 = data.DataLoader(train_data3, batch_size=args.inter_batch, shuffle=True, num_workers=0)
adj_norm3 = scipy_sparse_mat_to_torch_sparse_tensor(train3)
adj_norm3 = adj_norm3.coalesce().cuda(torch.device(device))
print('Adj matrix normalized.')

# perform svd reconstruction
# adj = scipy_sparse_mat_to_torch_sparse_tensor(train).coalesce().cuda(torch.device(device))
# print('Performing SVD...')
# svd_u,s,svd_v = torch.svd_lowrank(adj, q=svd_q)
# u_mul_s = svd_u @ (torch.diag(s))
# v_mul_s = svd_v @ (torch.diag(s))
# del s
adj = scipy_sparse_mat_to_torch_sparse_tensor(train).coalesce().cuda(torch.device(device))
adj1 = scipy_sparse_mat_to_torch_sparse_tensor(train1).coalesce().cuda(torch.device(device))
adj2 = scipy_sparse_mat_to_torch_sparse_tensor(train2).coalesce().cuda(torch.device(device))
adj3 = scipy_sparse_mat_to_torch_sparse_tensor(train3).coalesce().cuda(torch.device(device))
# process test set

test_labels = [[] for i in range(test2.shape[0])]

for i in range(len(test2.data)):
    row = test2.row[i]
    col = test2.col[i]
    test_labels[row].append(col)
print('Test data processed.')

loss_list = []
loss_1_list = []
loss_2_list = []
loss_s_h_list = []
recall_10_x = []
recall_10_y = []
ndcg_10_y = []
recall_20_x = []
recall_20_y = []
ndcg_20_y = []
recall_50_y = []
ndcg_50_y = []
dataset = DataSet()
model = DBCSSL(adj_norm.shape[0], adj_norm.shape[1], d, train_csr2, adj_norm, adj_norm1, adj_norm2, l1, l2, l3, cl1, cl2, cl3, eps,
                temp, lambda_1, lambda_2, lambda_3, dropout, batch_user, device)
# model.load_state_dict(torch.load('saved_model.pt'))
model.cuda(torch.device(device))
optimizer = torch.optim.Adam(model.parameters(), weight_decay=0, lr=lr)
# optimizer.load_state_dict(torch.load('saved_optim.pt'))

current_lr = lr

for epoch in range(epoch_no):
    if (epoch + 1) % 50 == 0:
        torch.save(model.state_dict(), 'saved_model/saved_model_epoch_' + str(epoch) + '.pt')
        torch.save(optimizer.state_dict(), 'saved_model/saved_optim_epoch_' + str(epoch) + '.pt')
    epoch_loss = 0
    epoch_loss_1 = 0
    epoch_loss_2 = 0
    # epoch_loss_s_h = 0
    train_loader2.dataset.neg_sampling()
    for i, batch in enumerate(tqdm(train_loader2)):
        uids, pos, neg = batch
        uids = uids.long().cuda(torch.device(device))
        pos = pos.long().cuda(torch.device(device))
        neg = neg.long().cuda(torch.device(device))
        iids = torch.concat([pos, neg], dim=0)
        # feed
        optimizer.zero_grad()
        loss, loss_1, loss_2 = model(uids, iids, pos, neg)
        loss.backward()
        optimizer.step()

        epoch_loss += loss.cpu().item()
        epoch_loss_1 += loss_1.cpu().item()
        epoch_loss_2 += loss_2.cpu().item()

        torch.cuda.empty_cache()

    batch_no = len(train_loader2)
    epoch_loss = epoch_loss / batch_no
    epoch_loss_1 = epoch_loss_1 / batch_no
    epoch_loss_2 = epoch_loss_2 / batch_no
    # epoch_loss_s_h = epoch_loss_s_h / batch_no
    loss_list.append(epoch_loss)
    loss_1_list.append(epoch_loss_1)
    loss_2_list.append(epoch_loss_2)
    # loss_s_h_list.append(epoch_loss_s_h)
    print('Epoch:', epoch, 'Loss:', epoch_loss, 'Loss_1:', epoch_loss_1, 'Loss_2:', epoch_loss_2)

    if epoch % 3 == 0:  # test every 10 epochs
        test_uids = np.array([i for i in range(adj_norm2.shape[0])])
        batch_no = int(np.ceil(len(test_uids) / batch_user))

        all_recall_10 = 0
        all_ndcg_10 = 0
        all_recall_20 = 0
        all_ndcg_20 = 0
        all_recall_50 = 0
        all_ndcg_50 = 0
        for batch in tqdm(range(batch_no)):
            start = batch * batch_user
            end = min((batch + 1) * batch_user, len(test_uids))

            test_uids_input = torch.LongTensor(test_uids[start:end]).cuda(torch.device(device))
            predictions = model(test_uids_input, None, None, None, test=True)
            predictions = np.array(predictions.cpu())

            # top@10
            recall_10, ndcg_10 = metrics(test_uids[start:end], predictions, 10, test_labels)
            # top@20
            recall_20, ndcg_20 = metrics(test_uids[start:end], predictions, 20, test_labels)
            # top@40
            recall_50, ndcg_50 = metrics(test_uids[start:end], predictions, 50, test_labels)

            all_recall_10 += recall_10
            all_ndcg_10 += ndcg_10
            all_recall_20 += recall_20
            all_ndcg_20 += ndcg_20
            all_recall_50 += recall_50
            all_ndcg_50 += ndcg_50
            # print('batch',batch,'recall@20',recall_20,'ndcg@20',ndcg_20,'recall@40',recall_40,'ndcg@40',ndcg_40)
        print('-------------------------------------------')
        print('Test of epoch', epoch, ':', 'Recall@10:', all_recall_10 / batch_no, 'Ndcg@10:', all_ndcg_10 / batch_no,
              'Recall@20:', all_recall_20 / batch_no, 'Ndcg@20:', all_ndcg_20 / batch_no, 'Recall@50:',
              all_recall_50 / batch_no, 'Ndcg@50:', all_ndcg_50 / batch_no)
        recall_10_x.append(epoch)
        recall_10_y.append(all_recall_10 / batch_no)
        ndcg_10_y.append(all_ndcg_10 / batch_no)
        # recall_20_x.append(epoch)
        recall_20_y.append(all_recall_20 / batch_no)
        ndcg_20_y.append(all_ndcg_20 / batch_no)
        recall_50_y.append(all_recall_50 / batch_no)
        ndcg_50_y.append(all_ndcg_50 / batch_no)

# final test
test_uids = np.array([i for i in range(adj_norm2.shape[0])])
batch_no = int(np.ceil(len(test_uids) / batch_user))

all_recall_10 = 0
all_ndcg_10 = 0
all_recall_20 = 0
all_ndcg_20 = 0
all_recall_50 = 0
all_ndcg_50 = 0
for batch in range(batch_no):
    start = batch * batch_user
    end = min((batch + 1) * batch_user, len(test_uids))

    test_uids_input = torch.LongTensor(test_uids[start:end]).cuda(torch.device(device))
    predictions = model(test_uids_input, None, None, None, test=True)
    predictions = np.array(predictions.cpu())

    # top@10
    recall_10, ndcg_10 = metrics(test_uids[start:end], predictions, 10, test_labels)
    # top@20
    recall_20, ndcg_20 = metrics(test_uids[start:end], predictions, 20, test_labels)
    # top@40
    recall_50, ndcg_50 = metrics(test_uids[start:end], predictions, 50, test_labels)

    all_recall_10 += recall_10
    all_ndcg_10 += ndcg_10
    all_recall_20 += recall_20
    all_ndcg_20 += ndcg_20
    all_recall_50 += recall_50
    all_ndcg_50 += ndcg_50
    # print('batch',batch,'recall@20',recall_20,'ndcg@20',ndcg_20,'recall@40',recall_40,'ndcg@40',ndcg_40)
print('-------------------------------------------')
print('Test of epoch', epoch, ':', 'Recall@10:', all_recall_10 / batch_no, 'Ndcg@10:', all_ndcg_10 / batch_no,
      'Recall@20:', all_recall_20 / batch_no, 'Ndcg@20:', all_ndcg_20 / batch_no, 'Recall@50:',
      all_recall_50 / batch_no, 'Ndcg@50:', all_ndcg_50 / batch_no)
recall_10_x.append(epoch)
recall_10_y.append(all_recall_10 / batch_no)
ndcg_10_y.append(all_ndcg_10 / batch_no)
# recall_20_x.append(epoch)
recall_20_y.append(all_recall_20 / batch_no)
ndcg_20_y.append(all_ndcg_20 / batch_no)
recall_50_y.append(all_recall_50 / batch_no)
ndcg_50_y.append(all_ndcg_50 / batch_no)

metric = pd.DataFrame({
    'epoch': recall_10_x,
    'recall@20': recall_10_y,
    'ndcg@20': ndcg_10_y,
    # 'epoch':recall_20_x,
    'recall@20': recall_20_y,
    'ndcg@20': ndcg_20_y,
    'recall@40': recall_50_y,
    'ndcg@40': ndcg_50_y
})
current_t = time.gmtime()
metric.to_csv('log/result_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.csv')

torch.save(model.state_dict(),
           'saved_model/saved_model_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.pt')
torch.save(optimizer.state_dict(),
           'saved_model/saved_optim_' + args.data + '_' + time.strftime('%Y-%m-%d-%H', current_t) + '.pt')
