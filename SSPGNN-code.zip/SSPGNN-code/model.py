import pickle

import torch
import torch.nn as nn
import numpy as np
from utils import sparse_dropout, spmm
import torch.nn.functional as F
from parser1 import args
from math import sqrt
from data_set import DataSet
import os.path

class DBCSSL(nn.Module):
    def __init__(self, n_u, n_i, d, train_csr, adj_norm, adj_norm1, adj_norm2, l1, l2, l3,
                 cl1, cl2, cl3,  eps, temp, lambda_1, lambda_2, lambda_3, dropout,
                 batch_user, device):
        super(DBCSSL, self).__init__()
        self.E_u_0 = nn.Parameter(nn.init.xavier_uniform_(torch.empty(n_u, d)))
        self.E_i_0 = nn.Parameter(nn.init.xavier_uniform_(torch.empty(n_i, d)))

        self.train_csr = train_csr
        self.adj_norm = adj_norm
        self.adj_norm1 = adj_norm1
        self.adj_norm2 = adj_norm2

        self.l1 = l1
        self.l2 = l2
        self.l3 = l3

        self.layer_cl1 = cl1
        self.layer_cl2 = cl2
        self.layer_cl3 = cl3

        self.E_u_list = [None] * (l1 + 1)
        self.E_i_list = [None] * (l1 + 1)
        self.E_u_list1 = [None] * (l2 + 1)
        self.E_i_list1 = [None] * (l2 + 1)
        self.E_u_list2 = [None] * (l3 + 1)
        self.E_i_list2 = [None] * (l3 + 1)

        self.E_u_list[0] = self.E_u_0
        self.E_i_list[0] = self.E_i_0
        self.E_u_list1[0] = self.E_u_0
        self.E_i_list1[0] = self.E_i_0
        self.E_u_list2[0] = self.E_u_0
        self.E_i_list2[0] = self.E_i_0

        self.Z_u_list = [None] * (l1 + 1)
        self.Z_i_list = [None] * (l1 + 1)
        self.Z_u_list1 = [None] * (l2 + 1)
        self.Z_i_list1 = [None] * (l2 + 1)
        self.Z_u_list2 = [None] * (l3 + 1)
        self.Z_i_list2 = [None] * (l3 + 1)

        self.temp = temp
        self.lambda_1 = lambda_1
        self.lambda_2 = lambda_2
        self.lambda_3 = lambda_3
        self.dropout = dropout
        self.act = nn.LeakyReLU(0.5)
        self.batch_user = batch_user
        self.eps = eps
        self.device = device

        self.E_u = None
        self.E_i = None
        self.E_u_cl = None
        self.E_i_cl = None
        self.E_u1 = None
        self.E_i1 = None
        self.E_u_cl1 = None
        self.E_i_cl1 = None
        self.E_u2 = None
        self.E_i2 = None
        self.E_u_cl2 = None
        self.E_i_cl2 = None
        self.E_ut = None
        self.E_it = None

    def forward(self, uids, iids, pos, neg, test=False, perturbed=True):
        if test == True:  # testing phase
            preds = self.E_u2[uids] @ self.E_i2.T
            mask = self.train_csr[uids.cpu().numpy()].toarray()
            mask = torch.Tensor(mask).cuda(torch.device(self.device))
            preds = preds * (1 - mask) - 1e8 * mask
            predictions = preds.argsort(descending=True)
            return predictions
        else:  # training phase
            # 点击商品行为
            # all_user_embeddings = []
            for layer in range(1, self.l1 + 1):
                self.Z_u_list[layer] = torch.spmm(sparse_dropout(self.adj_norm, self.dropout), self.E_i_list[layer - 1])
                self.Z_i_list[layer] = torch.spmm(sparse_dropout(self.adj_norm, self.dropout).transpose(0, 1),
                                                  self.E_u_list[layer - 1])
                # aggregate
                self.E_u_list[layer] = self.Z_u_list[layer]
                self.E_i_list[layer] = self.Z_i_list[layer]
                if perturbed:
                    random_noise = torch.rand_like(self.E_u_list[layer]).cuda()
                    self.E_u_list[layer] += torch.sign(self.E_u_list[layer]) * F.normalize(random_noise,
                                                                                           dim=-1) * self.eps
                    random_noise1 = torch.rand_like(self.E_i_list[layer]).cuda()
                    self.E_i_list[layer] += torch.sign(self.E_i_list[layer]) * F.normalize(random_noise1,
                                                                                           dim=-1) * self.eps
                if layer == self.layer_cl1 - 1:
                    E_u_cl = self.E_u_list[layer]
                    E_i_cl = self.E_i_list[layer]
            self.E_u = torch.mean(torch.stack(self.E_u_list, dim=1), dim=1)
            self.E_i = torch.mean(torch.stack(self.E_i_list, dim=1), dim=1)
            # all_user_embeddings.append(self.E_u)
            # 加购物车行为
            self.E_u_list1[0] = self.E_u
            self.E_i_list1[0] = self.E_i
            for layer in range(1, self.l2 + 1):
                # GNN propagation
                self.Z_u_list1[layer] = torch.spmm(sparse_dropout(self.adj_norm1, self.dropout),
                                                   self.E_i_list1[layer - 1])
                self.Z_i_list1[layer] = torch.spmm(sparse_dropout(self.adj_norm1, self.dropout).transpose(0, 1),
                                                   self.E_u_list1[layer - 1])
                # aggregate
                self.E_u_list1[layer] = self.Z_u_list1[layer]
                self.E_i_list1[layer] = self.Z_i_list1[layer]
                if perturbed:
                    random_noise2 = torch.rand_like(self.E_u_list1[layer]).cuda()
                    self.E_u_list1[layer] += torch.sign(self.E_u_list1[layer]) * F.normalize(random_noise2,
                                                                                             dim=-1) * self.eps
                    random_noise3 = torch.rand_like(self.E_i_list1[layer]).cuda()
                    self.E_i_list1[layer] += torch.sign(self.E_i_list1[layer]) * F.normalize(random_noise3,
                                                                                             dim=-1) * self.eps
                if layer == self.layer_cl2 - 1:
                    E_u_cl1 = self.E_u_list1[layer]
                    E_i_cl1 = self.E_i_list1[layer]
            self.E_u1 = torch.mean(torch.stack(self.E_u_list1, dim=1), dim=1)
            self.E_i1 = torch.mean(torch.stack(self.E_i_list1, dim=1), dim=1)
            # 购买行为
            self.E_u_list2[0] = self.E_u1 + self.E_u
            self.E_i_list2[0] = self.E_i1 + self.E_i
            # self.E_u_list2[0] = torch.max(torch.stack((self.E_u1, self.E_u), dim=1),dim=1).values
            # self.E_i_list2[0] = torch.max(torch.stack((self.E_i1, self.E_i), dim=1),dim=1).values
            # self.E_u_list2[0] = torch.mean(torch.stack((self.E_u1, self.E_u), dim=1), dim=1)
            # self.E_i_list2[0] = torch.mean(torch.stack((self.E_i1, self.E_i), dim=1), dim=1)
            for layer in range(1, self.l3 + 1):
                self.Z_u_list2[layer] = torch.spmm(sparse_dropout(self.adj_norm2, self.dropout),
                                                   self.E_i_list2[layer - 1])
                self.Z_i_list2[layer] = torch.spmm(sparse_dropout(self.adj_norm2, self.dropout).transpose(0, 1),
                                                   self.E_u_list2[layer - 1])
                # aggregate
                self.E_u_list2[layer] = self.Z_u_list2[layer]
                self.E_i_list2[layer] = self.Z_i_list2[layer]
                if perturbed:
                    random_noise4 = torch.rand_like(self.E_u_list2[layer]).cuda()
                    self.E_u_list2[layer] += torch.sign(self.E_u_list2[layer]) * F.normalize(random_noise4,
                                                                                             dim=-1) * self.eps
                    random_noise5 = torch.rand_like(self.E_i_list2[layer]).cuda()
                    self.E_i_list2[layer] += torch.sign(self.E_i_list2[layer]) * F.normalize(random_noise5,
                                                                                             dim=-1) * self.eps
                if layer == self.layer_cl3 - 1:
                    E_u_cl2 = self.E_u_list2[layer]
                    E_i_cl2 = self.E_i_list2[layer]
            # self.E_u2 = torch.mean(torch.stack(self.E_u_list2, dim=1), dim=1)
            # self.E_i2 = torch.mean(torch.stack(self.E_i_list2, dim=1), dim=1)
            self.E_u2 = sum(self.E_u_list2)
            self.E_i2 = sum(self.E_i_list2)
            self.E_ut = self.E_u + self.E_u1 + self.E_u2
            self.E_it = self.E_i + self.E_i1 + self.E_i2
            # bpr loss
            u_emb = self.E_ut[uids]
            pos_emb = self.E_it[pos]
            neg_emb = self.E_it[neg]
            pos_scores = (u_emb * pos_emb).sum(-1)
            neg_scores = (u_emb * neg_emb).sum(-1)
            loss_rt = -(pos_scores - neg_scores).sigmoid().log().mean()
            # 原图：点击和购买对比损失、加购和购买对比损失
            E_u_norm2 = self.E_u2
            E_u_norm1 = self.E_u1
            E_u_norm = self.E_u
            E_i_norm2 = self.E_i2
            E_i_norm1 = self.E_i1
            E_i_norm = self.E_i
            neg_score20 = torch.log(torch.exp(E_u_norm2[uids] @ E_u_norm.T / self.temp).sum(1) + 1e-8).mean()
            neg_score20 += torch.log(torch.exp(E_i_norm2[iids] @ E_i_norm.T / self.temp).sum(1) + 1e-8).mean()
            pos_score20 = (torch.clamp((E_u_norm2[uids] * E_u_norm[uids]).sum(1) / self.temp, -5.0, 5.0)).mean() + (
                torch.clamp((E_i_norm2[iids] * E_i_norm[iids]).sum(1) / self.temp, -5.0, 5.0)).mean()
            loss_sst_1 = -pos_score20 + neg_score20
            neg_score21 = torch.log(torch.exp(E_u_norm2[uids] @ E_u_norm1.T / self.temp).sum(1) + 1e-8).mean()
            neg_score21 += torch.log(torch.exp(E_i_norm2[iids] @ E_i_norm1.T / self.temp).sum(1) + 1e-8).mean()
            pos_score21 = (torch.clamp((E_u_norm2[uids] * E_u_norm1[uids]).sum(1) / self.temp, -5.0, 5.0)).mean() + (
                torch.clamp((E_i_norm2[iids] * E_i_norm1[iids]).sum(1) / self.temp, -5.0, 5.0)).mean()
            loss_sst_2 = -pos_score21 + neg_score21
            #跨层对比学习
            neg_score1 = torch.log(torch.exp(E_u_norm[uids] @ E_u_cl.T / self.temp).sum(1) + 1e-8).mean()
            neg_score1 += torch.log(torch.exp(E_i_norm[iids] @ E_i_cl.T / self.temp).sum(1) + 1e-8).mean()
            pos_score1 = (torch.clamp((E_u_norm[uids] * E_u_cl[uids]).sum(1) / self.temp, -5.0, 5.0)).mean() + (
                torch.clamp((E_i_norm[iids] * E_i_cl[iids]).sum(1) / self.temp, -5.0, 5.0)).mean()
            loss_cl1 = -pos_score1 + neg_score1
            neg_score2 = torch.log(torch.exp(E_u_norm1[uids] @ E_u_cl1.T / self.temp).sum(1) + 1e-8).mean()
            neg_score2 += torch.log(torch.exp(E_i_norm1[iids] @ E_i_cl1.T / self.temp).sum(1) + 1e-8).mean()
            pos_score2 = (torch.clamp((E_u_norm1[uids] * E_u_cl1[uids]).sum(1) / self.temp, -5.0, 5.0)).mean() + (
                torch.clamp((E_i_norm1[iids] * E_i_cl1[iids]).sum(1) / self.temp, -5.0, 5.0)).mean()
            loss_cl2 = -pos_score2 + neg_score2
            neg_score3 = torch.log(torch.exp(E_u_norm2[uids] @ E_u_cl2.T / self.temp).sum(1) + 1e-8).mean()
            neg_score3 += torch.log(torch.exp(E_i_norm2[iids] @ E_i_cl2.T / self.temp).sum(1) + 1e-8).mean()
            pos_score3 = (torch.clamp((E_u_norm2[uids] * E_u_cl2[uids]).sum(1) / self.temp, -5.0, 5.0)).mean() + (
                torch.clamp((E_i_norm2[iids] * E_i_cl2[iids]).sum(1) / self.temp, -5.0, 5.0)).mean()
            loss_cl3 = -pos_score3 + neg_score3
            # reg loss
            loss_reg = 0
            for param in self.parameters():
                loss_reg += param.norm(2).square()
            loss_reg *= self.lambda_3
            loss_r = loss_rt
            loss_cl = loss_cl1 + loss_cl2 + loss_cl3
            loss_sst = loss_sst_1 + loss_sst_2
            # total loss
            loss = loss_r + self.lambda_1 * loss_cl + self.lambda_2 * loss_sst + loss_reg
            return loss, loss_r, self.lambda_3 * loss_sst
