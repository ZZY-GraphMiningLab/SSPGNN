import argparse
import os
import random
import json
import torch

from torch.utils.data import Dataset, DataLoader
import numpy as np


class DataSet(object):

    def __init__(self):
        self.__get_sparse_interact_dict()

    def __get_sparse_interact_dict(self):

        self.item_behaviour_degree = []
        with open('./data/taobao/view/train2.txt', encoding='utf-8') as f:
            data = f.readlines()
            row = []
            col = []
            for line in data:
                line = line.strip('\n').strip().split()
                row.append(int(line[0]))
                col.append(int(line[1]))
            indices = np.vstack((row, col))
            indices = torch.LongTensor(indices)

            values = torch.ones(len(row), dtype=torch.float32)
            user_inter = torch.sparse.FloatTensor(indices, values, [15449 + 1, 11902 + 1]).to_dense()
            self.item_behaviour_degree.append(user_inter.sum(dim=0))
        with open('./data/taobao/cart/train2.txt', encoding='utf-8') as f:
            data = f.readlines()
            row = []
            col = []
            for line in data:
                line = line.strip('\n').strip().split()
                row.append(int(line[0]))
                col.append(int(line[1]))
            indices = np.vstack((row, col))
            indices = torch.LongTensor(indices)

            values = torch.ones(len(row), dtype=torch.float32)
            user_inter = torch.sparse.FloatTensor(indices, values, [15449 + 1, 11902 + 1]).to_dense()
            self.item_behaviour_degree.append(user_inter.sum(dim=0))
        with open('./data/taobao/buy/train2.txt', encoding='utf-8') as f:
            data = f.readlines()
            row = []
            col = []
            for line in data:
                line = line.strip('\n').strip().split()
                row.append(int(line[0]))
                col.append(int(line[1]))
            indices = np.vstack((row, col))
            indices = torch.LongTensor(indices)

            values = torch.ones(len(row), dtype=torch.float32)
            user_inter = torch.sparse.FloatTensor(indices, values, [15449 + 1, 11902 + 1]).to_dense()
            self.item_behaviour_degree.append(user_inter.sum(dim=0))
        self.item_behaviour_degree = torch.stack(self.item_behaviour_degree, dim=0).T


if __name__ == '__main__':
    dataset = DataSet()
